﻿using Microsoft.AspNetCore.Mvc;

namespace WebProject7MartV1.Controllers
{
    public class IletisimController : Controller
    {
        public IActionResult BizeYazin()
        {
            return View();
        }
    }
}
