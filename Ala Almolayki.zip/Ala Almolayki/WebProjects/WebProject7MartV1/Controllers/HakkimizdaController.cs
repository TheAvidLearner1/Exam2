﻿using Microsoft.AspNetCore.Mvc;

namespace WebProject7MartV1.Controllers
{
    public class HakkimizdaController : Controller
    {
        public IActionResult Bilgiler()
        {
            return View();
        }
    }
}
